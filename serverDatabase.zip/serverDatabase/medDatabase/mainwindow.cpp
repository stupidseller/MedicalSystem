#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlQuery>
#include <QStandardItemModel>
#include <QStandardItem>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // init sql
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("hospital_management.db");

    if( !db.open() ) {
        QMessageBox::critical(this, "Error", "Open database fail");
        return;
    }

    QSqlQuery query;
        if (!query.exec("SELECT user_id, phone FROM users")) {
            QMessageBox::critical(this, "SQL Error", "数据库查询失败");
            return;
        }
    QStandardItemModel *model = new QStandardItemModel(0,2,this);
    model->setHorizontalHeaderItem(0, new QStandardItem("user_id "));
    model->setHorizontalHeaderItem(1, new QStandardItem("phone"));

    int i = 0;
    while (query.next()) {
        model->setItem(i, 0, new QStandardItem(query.value(0).toString()));
        model->setItem(i, 1, new QStandardItem(query.value(1).toString()));
        i++;
    }

    ui->tableView->setModel(model);

   }

MainWindow::~MainWindow()
{
    delete ui;
}
